# Handoff: 中考英语 AI 试卷生成器 — 前端 UI

## Overview

这是 `lzclzclzclzclzclzc/English_Test_Paper_AI_Generator`（分支 `master`，只含 5 份设计 spec，尚无前端代码）的完整前端 UI 设计。

覆盖 11 个界面：1 个对外落地页 + 登录/注册 + 9 个应用内屏幕。设计目标是把后端 spec C 的 11 个 HTTP 端点、AI Engine 的五个模块、ingestion 管线的六个阶段全部在界面上表达出来，并把 spec D 原本的三页 MVP 扩成可商用的产品结构（左侧可折叠导航 + 多屏）。

## About the Design Files

本包里的 HTML 是**设计参考**，不是可以直接搬进仓库的生产代码。它是一个自包含的 HTML 原型（内联样式 + 一个逻辑类），用来说明「长什么样、怎么交互」。

实现任务是：**在目标仓库既有环境里重建这些设计** —— 即 spec D 定的 Vite + React + TypeScript + shadcn/ui + Tailwind + TanStack Query + React Router，遵循该仓库已确立的模式（`api/` 层封装 fetch、组件不直接 fetch、服务端状态只走 TanStack Query）。不要把 HTML 直接塞进 `index.html`。

## Fidelity

**High-fidelity（hifi）。** 颜色、字号、行高、间距、边框、hover 态都是最终值，应当像素级还原。唯一例外是插图/照片：设计里刻意没有图片（设计系统禁止用色块假装图片）。

## 设计系统

外观来自「喫茶去」设计系统 —— 暖纸底、软炭墨字、单一赤陶强调色。三条硬规则，实现时必须守住：

1. **One Chroma Rule** — 赤陶（Terracotta Coral）是全站唯一的饱和色，只用于交互与强调（主按钮、选中态、当前导航项、进度条、错题标记、薄弱知识点）。**不用绿/黄/红做语义色**（注意：spec D §3.6 写的「绿/黄/红」掌握度分级在此设计中改为赤陶不透明度分级 —— 这是与 spec 的有意偏离，需同步 spec 或按 spec 改回）。
2. **Tinted Neutral Rule** — 禁止 `#000`/`#fff` 和无色阶灰。所有边框、分隔线、hover 底色都是不透明度分级的墨色（`--ink-5/10/15/20/30`）。
3. **Flat-Paper Rule** — 无静置阴影、无卡片盒子、无左边框强调条。层次靠 1px 细线、色调底纹和留白。

字体全部衬线：正文 `--font-serif`（中文思源宋体 / 拉丁 Georgia），页眉品牌用 `--font-display`（京华老宋体），代码用 `--font-mono`。**只有 400 和 700 两个字重**，不要造中间字重。

## Design Tokens

完整 token 见本包 `tokens/*.css`（可直接拷进 `src/styles/`）。核心值：

| Token | 值 | 用途 |
|---|---|---|
| `--ink` | `oklch(38% 0.004 90)` ≈ `#353534` | 所有文字、边框的基色 |
| `--rice-cream` | `oklch(96.8% 0.005 95)` ≈ `#f6f5f1` | 页面底色 |
| `--accent` | `oklch(49% 0.155 33)` 赤陶 | 唯一强调色 |
| `--accent-wash` | `color-mix(in oklab, accent 18%, transparent)` | 主按钮底、选中底、高亮底 |
| `--ink-5 / 10 / 15 / 20 / 30` | 墨色 5%/10%/15%/20%/30% | hover 底 / 弱线 / 默认细线 / 强线 / 下划线 |
| `--border-hairline` | `= --ink-15` | 默认 1px 分隔线 |
| `--text-muted` / `--text-quiet` | 墨色 82% / 75% | 次要文字 / 标签与日期（对比度下限） |
| 深色模式 | `.dark` 类，底 `oklch(24% 0.016 72)`，强调 `oklch(72% 0.13 35)` | 设置页可切换 |

**字号 / 行高**（px）：落地页大标题 58/1.32；页面 h1 30/400；区块 h2 24/400；小节标题 17–19；正文 15–16，行高 1.9，正文宽度上限 42rem；表格与元信息 13–14；标签 10.5–12 / 700 / letter-spacing 0.1–0.14em（拉丁大写标签）。

**圆角**：0.25rem（按钮、chip、格子）、0.375rem（代码块、解析框、头像）、3px（输入框）。**不要用胶囊圆角。**

**间距**：页面左右 56px；屏内区块间 40–56px；列表项上下 18–28px；网格 gap 8–20px。

**动效**：只有两个 —— `kk-rise`（opacity 0→1 + translateY 8px→0，0.3s ease-out，用于面板展开）和 `kk-pulse`（opacity 0.35↔1，1.1s，用于管线当前步骤的圆点）。宽度过渡 0.25–0.4s ease-out。无弹跳、无装饰性循环。

## Screens / Views

### 1. 落地页 `/`（未登录）

- **粘顶页眉**：左品牌「中考英语 AI 试卷生成器」（display 字体 21px，letter-spacing 0.06em）；右三个锚点链接（流程 / 模式 / 题库，14px，hover 转赤陶）+ 「进入 →」按钮（赤陶边 + `--accent-wash` 底）。页眉 `backdrop-filter: saturate(1.4) blur(8px)`，底色为页面色 88% 混透明，下边一条细线，**无阴影**。
- **Hero**（padding 120/56/88，最大宽 1180，居左不居中）：赤陶小标签「RAG + 大模型 · 中考英语 · 纯文字题型」；58px 大标题，其中「出一份能直接做的卷子」带 `--accent-wash` 高亮底；42rem 宽正文段；一个主按钮「开始生成试卷」（**只有一个 CTA，不要再加次级链接**）。
- **数据条**（细线上方 76px）：4 项赤陶数字 32px —— 4,180 题库题量 / 3 类题型 / 6 秒生成 / 26 知识点。
- **`#how` 生成流程**：四等分网格，上边框为赤陶实线，列间 1px 细线。每列：赤陶 11px 编号（01 · PARSER …）、18px 小标题（解析要求 / 检索题库 / 改题加工 / 成卷落库）、14px 说明。
- **`#engine`**：左右两栏（1fr 1fr，gap 72）。左「三种模式」——FRESH / REMEDIATION / REVIEW 三条细线分隔的条目，模式代号赤陶 12px 定宽 88px。右「判分规则」——说明段 + 一个细线圆角框内的等宽代码演示，`true` 带赤陶高亮底。
- **`#bank`**：题库说明 + 六个流程 chip（EPUB→md / 章节切分 / 知识点树归并 / **人工审核**（赤陶边+底）/ 结构化抽题 / 双写入库）；末尾细线上一行收尾文案 + 「开始使用 →」按钮。

### 2. 登录 / 注册

左右两栏（1.15fr / 1fr，中间竖细线）。左栏上中下三段：品牌（点击回落地页）、26px 说明句（含赤陶高亮）、底部小字（用户名+密码本地登录 · 会话 30 天滑动过期）。右栏 24rem 表单：登录/注册两个 tab（选中项 2px 赤陶下边框），用户名 + 密码输入（3px 圆角，focus 时边框转赤陶），校验提示小字（3–32 位字母数字下划线 · 密码 6–128 位），赤陶主按钮，末尾「返回首页」。

对齐 spec C §2.1 `UserCredentials`：`username` `^[a-zA-Z0-9_]+$` 3–32，`password` 6–128。Zod schema 必须与后端一致。

### 3. 应用外壳 —— 左侧可折叠导航

- 展开 232px / 收起 66px，`transition: width .25s ease-out`，`position: sticky; top:0; height:100vh`，右侧 1px 细线。
- 顶部 64px：品牌「试卷生成器」（收起时隐藏）+ 折叠按钮（30×30 图标按钮，lucide `panel-left`）。
- 三组导航，组标签 10.5px/700/0.14em 弱色：**出卷**（生成试卷 / 当前试卷 / 历史试卷）、**复习**（成绩与解析 / 错题本 / 掌握度）、**资料**（题库 / 题库摄入 / 设置）。**收起时组标签变成一条 1px 细线分隔符，不要留半个字。**
- 导航项：图标 18px（lucide，stroke-width 1.5，`currentColor`）+ 14.5px 文字，gap 12，padding 9/12，圆角 0.25rem。当前项 = `--accent-wash` 底 + 赤陶字；非当前 = 透明底 + `--text-muted`。
- 底部：30×30 头像方块 + 用户名 + 「登出」小字链接。

### 4. 生成试卷（`POST /api/papers/generate`）

- 页眉小标签写端点名（11–12px 大写弱色，全站每屏都有，作为「这屏对应哪个接口」的提示，上线时可保留也可去掉）。
- h1「生成试卷」+ 说明段。
- 44rem 宽 `<textarea>`（4 行，16px，行高 1.8，focus 边框转赤陶），预填示例：「来 12 道现在完成时的单项选择，中等难度，最好带点时间状语的辨析」。
- 两组分段按钮：**出卷模式**（新生成 / 错题巩固 / 综合复习 → `mode: fresh|remediation|review`）、**题量**（10 / 12 / 20）。选中态 = 赤陶边 + `--accent-wash` 底。
- **知识点 chips**（可留空）：6 个可多选 chip，选中同上。
- 主按钮「生成试卷 / 生成中… / 重新生成」+ 右侧状态小字（通常 4–6 秒 / 生成中，请勿关闭页面 / 已完成，可以开始作答）。
- **管线进度**（点击生成后 `kk-rise` 展开）：标题行 `PIPELINE` + 右侧计时（0.1s 精度）。四步，每步一行网格 `22px 1fr auto`：状态圆点（完成 ✓ 墨色边；进行中 · 赤陶 + `kk-pulse`；未开始 弱边）、步骤名 + 详情小字 + 2px 进度条（进行中 55% 赤陶，完成 100% 赤陶 55% 不透明）、右侧耗时等宽小字。四步详情文案（照抄）：
  1. `Parser · 解析意图` — 现在完成时 · single_choice · 12 题 · 难度 medium · revision_intensity=light（0.8s）
  2. `Retriever · 检索题库` — 硬过滤 214 题 ∩ 向量 Top-60 → 命中 31 题｜《语法专项突破》第 7 章、《三年真题》2023 卷（1.2s）
  3. `Reviser · 按力度加工` — 原题 4 · 轻改 6 · 新出 2；1 题校验未过已回落原题（2.6s）
  4. `Assemble · 组卷落库` — paper_id 7f3a91c4 写入 papers 表，payload 18 KB（0.3s）
- 完成后一行：「已生成 12 题 · 原题 4 · 轻改 6 · 新出 2」+ 「开始作答 →」。

> **实现注意**：后端目前同步返回（spec C 明确不做 SSE/WebSocket）。原型里的分步进度是按 1.2s / 2.6s / 4.0s / 5.4s 的时间轴演出来的。可选三种落地方式：(a) 保留假进度 + 真耗时（最省事，体验已足够）；(b) 后端加 SSE 推送真实阶段；(c) 只显示不确定态骨架。

### 5. 当前试卷 / 作答

两栏 `minmax(0,1fr) 280px`。

**左（52rem 宽长卷）**：`PAPER · 7f3a91c4` 标签、30px 标题、一行元信息（生成时间 · 12 题 · 满分 60 · 题源书名章节）、两个次级按钮「重新生成」「打印 / 导出」，下方一条细线。
- 「重新生成」展开一个 44rem 的细线圆角面板（`POST /api/papers/revise`）：2 行 textarea + 「重新生成（新 paper_id）」+ 「取消」。
- 每题一个 `<article>`，底部 1px 细线，间距 40px：题号（等宽 13px 弱色）+ 题型/知识点/改题档位标签（11px 大写弱色，如 `SINGLE CHOICE · 现在完成时 · LIGHT 轻改`）；17px 题干，行高 1.9；
  - **单选**：34rem 宽的纵向选项按钮列表（gap 8），每项 padding 11/16，圆角 0.25rem，选项字母等宽 13px 0.7 透明度 + 16px 右距。**选中 = 赤陶边 + `--accent-wash` 底。**
  - **填空（word_form / sentence_rewriting）**：16rem 宽下划线输入框（无边框，只有 1px 底线，focus 转赤陶）+ 右侧提示「一题一空 · 大小写与句末标点不计」。
- 底部主按钮「提交判分」+ 「已答 N 题，未答 M 题」。

**右（280px 粘顶答题卡）**：`答题卡` 标签、`N / 12` 大字、2px 赤陶进度条、4 列题号方格（34px 高，已答 = 赤陶边 + wash 底；未答 = 弱边 + 弱字）、底部说明小字。

### 6. 成绩与解析（`POST /api/attempts` + `POST /api/solutions`）

- 顶部四项统计：总分 45/60（44px）、答对 9、**错题 3（赤陶）**，右侧两个按钮「按错题生成巩固卷」（主，赤陶）「查看掌握度」（次）。
- 每题一行 `26px 1fr` 网格：状态圆（对 = ✓ 墨色边；错 = ✕ 赤陶边+赤陶字）、题干 16px、一行三段元信息（你的答案 —— 错时赤陶 / 正确答案 / 知识点 id）、「查看解析 / 收起解析」文字按钮（下划线，hover 赤陶）。
- 解析展开为细线圆角框（`kk-rise`）：顶部小标签 `POST /API/SOLUTIONS · 按需生成`，正文 15px 行高 1.95。解析按需请求，不随判分一起返回（spec C §13 开放问题 5）。

### 7. 掌握度（`GET /api/users/me/mastery?window_days=30`）

- 四项统计：累计答题 218 / 综合正确率 73% / 覆盖知识点 14 of 26 / **建议优先补的薄弱点 4（赤陶）**。
- 按一级知识点（题型）分组，组标题可折叠（`−` / `+` 等宽符号），右侧组摘要。
- 每个叶子知识点一行网格 `minmax(0,1fr) 88px 200px 64px`：名称 + `kp_id · N 次作答`、正确率、6px 高进度条（宽度 = wilson×100%，赤陶；wilson ≥ 0.4 时不透明度 0.45，< 0.4 时 1.0 —— 即薄弱点更醒目）、wilson 分数（等宽，薄弱点赤陶）。
- 底部：薄弱点一句话总结 + 「按薄弱点生成试卷 →」。

### 8. 历史试卷（`GET /api/papers`）

无卡片的行式列表。每行网格 `110px minmax(0,1fr) auto`：等宽日期、标题 + 元信息小字（题量 · 满分 · mode · 改题配比）、右侧状态（已交 45/60 或 未作答）。整行可点，hover 加 `--hover-tint` 底。底部说明：重新生成产生新 paper_id，旧试卷保留。

### 9. 错题本

行式列表，网格 `26px minmax(0,1fr) 130px`：勾选方块（选中 = 赤陶边 + wash 底 + ✓）、题干 + 「知识点 · 错 N 次 · 最近日期」、右侧「你答 X 正确 Y」。底部主按钮「用选中错题生成巩固卷」+ 「已选 N 道 · mode=remediation」。

> **后端缺口**：spec C 没有「按用户聚合错题」的端点。需要新增（例如 `GET /api/users/me/wrong-items?window_days=`），或前端从 `GET /api/papers` + 各 attempt 拼，成本更高。建议新增端点。

### 10. 题库浏览（只读）

搜索框（22rem）+ 6 个筛选 chip（题型 3 个 + 难度 3 个）。下方 5 列表格式列表 `minmax(0,1fr) 150px 110px 90px 130px`：题干 / 知识点 / 题型 / 难度 / 题源。表头 11px 大写弱色 + `--ink-20` 下边线，行间细线，hover 底纹。

### 11. 题库摄入 / 知识点树审核（ingestion 控制台）

- 六阶段列表，网格 `30px minmax(0,1fr) 150px`：状态圆（完成 ✓ / 进行中 · 赤陶 / 等待 弱边空心）、阶段名（`epub_to_md`、`chapter_splitter`、`knowledge_tree_builder`、`★ 人工审核`、`question_extractor`、`loader`）+ 详情、右侧状态（完成 / 待你确认（赤陶）/ 等待）。
- 「待审核的知识点树草稿」：等宽字体的树形展示（一级题型 + 二级考点 + 题量），细线圆角框。
- 两个按钮：「确认并写入 knowledge_tree.json」（主）/「下载草稿手动修改」（次）。

### 12. 设置

细线分隔的行式列表：账号（用户名 · 注册日期 · 会话策略 + 改密码）、默认题量与难度、阅读外观（纸色 Ink / 深墨地 Deep Ink 两个分段按钮，切换 `document.documentElement.classList.toggle('dark')`）、速率限制说明（生成 30/min · 解析 60/min，只读）。

## Interactions & Behavior

| 交互 | 行为 |
|---|---|
| 侧栏折叠 | width 232↔66，0.25s ease-out；标签与品牌 `display:none`；组标签变细线 |
| 生成 | 点击后展开管线面板，四步依次点亮，完成后出现「开始作答」 |
| 选项选择 | 单选按钮组，选中态赤陶；同步更新右侧答题卡格子与进度条 |
| 提交判分 | 跳到成绩屏（真实实现为 `POST /api/attempts` 后展开成绩区，可留在同屏） |
| 查看解析 | 手风琴，同一时刻只展开一题（原型行为），`kk-rise` 进入 |
| 掌握度分组 | 点击组标题折叠/展开 |
| 错题勾选 | 多选，底部计数实时更新 |
| 主题切换 | 给 `<html>` 加 `.dark` 类 |
| hover | 统一 = `--hover-tint`（墨色 5%）底 或 文字转赤陶。**无位移、无阴影、无放大。** |

## State Management

沿用 spec D：服务端状态全部走 TanStack Query，UI 状态用组件 state。

**服务端（TanStack Query）**：`['auth','me']`、`['paper', paperId]`、`['papers','list']`、`['mastery','me']`、（新增）`['wrongItems','me']`、`['bank', filters]`。

**UI（组件 state）**：`sidebarCollapsed`（建议持久化到 localStorage）、`authTab`、生成表单的 `mode/count/selectedKps`、`answers: Record<index, string>`、`revisePanelOpen`、`openSolutionIndex`、`masteryGroupsOpen`、`wrongSelected`、`bankFilters`、`theme`。

**注意**：`answers` 只在内存中，刷新丢失（spec D §4.3 已接受）。答题卡组件读同一份 `answers`，不要复制第二份。

## 与 spec 的差异清单（实现前请先决定）

1. **屏幕数**：spec D 是三页，本设计是 11 屏。多出：历史试卷、错题本、题库浏览、题库摄入后台、设置。前端可分阶段上线（先三页 + 侧栏，再补其余）。
2. **错题本端点缺失**（见上）。
3. **题库浏览端点缺失**：需要 `GET /api/questions?…` 只读检索端点。
4. **掌握度配色**：spec 的绿/黄/红 → 本设计用赤陶不透明度分级。
5. **进度条**：后端同步返回，进度为演示（见第 4 屏说明）。
6. **深色模式**：spec D §10 列为非目标，本设计的设置页提供了切换（token 已支持，成本很低）。

## 落地建议（Tailwind + shadcn 映射）

1. 把 `tokens/*.css` 拷进 `src/styles/`，在 `main.tsx` 引入。
2. `tailwind.config.js` 里把颜色指到 CSS 变量：
   ```js
   colors: {
     ink: 'var(--ink)', paper: 'var(--surface-page)',
     accent: 'var(--accent)', 'accent-wash': 'var(--accent-wash)',
     hairline: 'var(--border-hairline)',
   }
   ```
   并把 shadcn 的 `--background / --foreground / --border / --primary / --muted-foreground` 指向对应 token，这样 shadcn 组件自动进入这套外观。
3. `fontFamily`: `serif → var(--font-serif)`、`display → var(--font-display)`、`mono → var(--font-mono)`。
4. shadcn 组件用量：Button、Input、Textarea、Label、Tabs、RadioGroup、Select、Dialog、Toast、Skeleton、Collapsible、Checkbox。**不要用 Card**（设计系统禁止卡片盒子），列表用细线分隔的 `<div>` 网格。
5. 组件拆分建议：`AppShell` / `Sidebar` / `GenerateForm` / `PipelineProgress` / `PaperView` / `QuestionCard` / `AnswerCard` / `GradeResult` / `SolutionPanel` / `MasteryTree` / `PaperList` / `WrongItemList` / `BankTable` / `IngestionStages` / `SettingsList` / `RequireAuth`。

## Assets

无图片、无第三方图标库文件。图标是 Feather/Lucide 风格的内联 SVG，`viewBox 0 0 24 24`、`fill:none`、`stroke:currentColor`、`stroke-width:1.5`、圆头圆角、渲染 18px。用到的：pen（生成）、file-text（当前试卷）、list（历史）、check-circle（成绩）、x-circle（错题）、bar-chart（掌握度）、book-open（题库）、database（摄入）、settings（设置）、panel-left（折叠）。直接装 `lucide-react` 并统一 `strokeWidth={1.5}` 即可。

字体：中文思源宋体（Noto Serif SC）走系统栈回退；`--font-display` 京华老宋体是 ~8KB 子集 woff2，未包含在本包内（仅页眉品牌用，缺失时回退到正文衬线，可接受）。

## Files

- `试卷生成器.dc.html` — 全部 11 屏的设计原型（用浏览器直接打开；左侧导航切换应用内各屏，落地页的「进入 →」进入登录）
- `tokens/colors.css`、`typography.css`、`spacing.css`、`fonts.css`、`base.css` — 设计 token 源文件，可直接拷入代码库
- 上游 spec：仓库 `docs/` 下 5 份（frontend-design 为 Spec D，backend-design 为 Spec C）
